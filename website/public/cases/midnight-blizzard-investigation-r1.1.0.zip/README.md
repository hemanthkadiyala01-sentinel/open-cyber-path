# OpenCyberPath CaseLab — The Unexpected Consent

**Case revision:** 1.1.0  
**Classification:** Synthetic training dataset inspired by public incident reporting  
**Status:** Candidate case pending human technical review

## Safety and evidence integrity

All identity names, application names, event IDs, timestamps, network addresses and activity records in this bundle are fictional. `198.51.100.24` is from a documentation-only IPv4 range. This bundle is not Microsoft telemetry and does not reproduce logs from an affected organisation. Use it for local defensive analysis only; do not contact or test any real target.

## Mission

Reconstruct the identity and application activity timeline; evaluate whether the records support suspected identity/application misuse; compare the possible benign explanation; scope what is known and unknown; and propose response actions with verifiable completion checks.

## Files

- `all-events.jsonl`: one synthetic event per line, in JSON Lines format.
- `all-events.csv`: the same events in tabular form.
- `identity-events.csv`: sign-in and conditional-access records.
- `application-audit.csv`: application consent, permission, credential and inventory records.
- `mailbox-audit.csv`: mailbox reads and the known-good control record.
- `response-and-context.csv`: owner confirmation, change lookup, containment tracker, role review and evidence-collection context.
- `manifest.json`: case revision, field definitions, evidence classification and SHA-256 hashes for data files.

## Investigation tasks

1. Build an ordered UTC timeline. Identify the pivot events and explain why authentication failures followed by success are not sufficient to prove compromise.
2. Correlate the consent, permission, app credential and mailbox events across records. Identify what ties them together and what needs authoritative confirmation.
3. Test alternative explanations. Compare change-management and owner records with the known-good app control. Explain limitations of missing inventory or ticket entries.
4. Determine the maximum defensible claim about access and scope. Do not equate read-operation counts with unique messages or confirmed exfiltration.
5. Recommend response steps in a justified order, preserving evidence and distinguishing requested changes from verified completion.
6. Define post-response checks, expected results and the person or role that confirms closure.

## Local analysis suggestions

Use tools already available on your own machine. For example, Python's standard library can parse the JSON Lines file, sort timestamps and group events by `principal` or `sourceType`; PowerShell can import CSV files and sort by `timestampUtc`. Record the commands and transformations used so another analyst can reproduce the timeline. No network interaction, live target, malware execution or production account is required.

## Field notes

- `timestampUtc`: event time expressed in UTC (`Z`).
- `sourceType`: the fictional source system for the record.
- `principal`: the identity or application recorded by that source; names are synthetic.
- `source`: fictional source label or documentation-range IP address.
- `result`: source-reported outcome; not necessarily a verified security conclusion.
- `detail`: training context and limitations for interpretation.
- `classification`: every row must remain `synthetic`.

## Source context

The case framing cites the Microsoft public incident disclosure (2024-01-19), Microsoft responder guidance (2024-01-25), Microsoft's update (2024-03-08), and CISA Emergency Directive 24-02 (2024-04-11). Those materials support the documented incident context and defensive lessons—not the fictional event records in this bundle.

- https://www.microsoft.com/en-us/msrc/blog/2024/01/microsoft-actions-following-attack-by-nation-state-actor-midnight-blizzard/
- https://www.microsoft.com/en-us/security/blog/2024/01/25/midnight-blizzard-guidance-for-responders-on-nation-state-attack/
- https://www.microsoft.com/en-us/msrc/blog/2024/03/update-on-microsoft-actions-following-attack-by-nation-state-actor-midnight-blizzard
- https://www.cisa.gov/news-events/directives/ed-24-02-mitigating-significant-risk-nation-state-compromise-microsoft-corporate-email-system
